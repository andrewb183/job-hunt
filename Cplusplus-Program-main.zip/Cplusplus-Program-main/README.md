# Cplusplus-Program

Summarize the project and what problem it was solving.
overall the biggest problem i had was working the ide and it working right. when i did go for help i got alot of information back on what to do and at times it was too munch to handle.  In the end alot of it i code not do since i did not have access to the vmware so i ended up downloading my own ide and that made thing work alot better for me.

What did you do particularly well?
as for what i did well in i would have to say codeing the project for the most part. the ide in the vmware was what was messing me up the most by giving me error that were just not their in the long run.

Where could you enhance your code? How would these improvements make your code more efficient, secure, and so on?
 so on the last projects i know i could make alot of improvements and secure as well. and here is how. i could have had added a password to to access the txt file. Then i could have made it more  flexble on adding tracking data to all types of animals and bugs too.

Did you find writing any piece of this code challenging, and how did you overcome this? What tools and/or resources are you adding to your support network?
 the last project was the hardest since i had trouble adding the JNI.h  the vmware keeped tell me i had it worng but i did everthing right. and that was confirmed by the teacher as well. By the time he got back to me i got it mostly fix by just deleting it and redoing it untill it went away. this was most likely something with the vmware since i can't get it setup on my pc yet and am going to work on it over my break from school and work.

What skills from this project will be particularly transferable to other projects and/or course work?
i would have to say my top one from this coure would be the JNI.h and know that i know about the JNI i have started looking how to join other languages to cpp to do other thing with it as well.

How did you make this program maintainable, readable, and adaptable?
I feel for the most part i did all three listed here. Even if its not the whole code pices of it i could see it being used for other thing in cpp. I know copy and paste it a big thing in coding. and being able to adaptable other code to be your own code at times in the work place.
