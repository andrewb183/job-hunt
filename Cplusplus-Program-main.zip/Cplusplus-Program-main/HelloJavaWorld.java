import java.io.InputStreamReader;
public class HelloJavaWorld
{
public static void sayhi()
{
System.out.println("Hello from JAVA world!!");
}
}