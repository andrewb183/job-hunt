# CS-230Operating-Platforms- Andrew Bolton

project final

The client was The Gaming Room. They currently had a game called Draw It or Lost It for Android. The Gaming Room wanted to improve the software functionality and to expand to other platforms. I kept this document clear, concise, and to the point to the best that I could and did go for some help to look over it to see if I was missing anything since another pair of eyes never hurt.

keeping my focus on the task on hand and to decide on what tasks are important and which ones don't need time and focus on at that time.

Recommendations was hard for me, I no idea what is needed it all go into it and not to make it too long and but also not to short.

I took what the functionality of the game and helped split it up so that there would be less work and time spend expanding to other operating platforms. All while keeping the game the same. Your client may be the one to ask you to do the work but it is the user's who truly control the product and the way if formal base on the feedback you get. If they do not trust the software or have problems with it then they won't use it and no more product and mostly no more job.
I put my focus on clear documentation and separating game and game needs functionality to allow easier updates and maintenance, and to look for farther ahead to see were it is going to make it easier to make the update faster as well

