package appoment;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;
class AppointmentServiceTest {
	Date date = new Date(2021, Calendar.FEBRUARY, 19);

	@Test
	void testAddAppt() {
		AppointmentService appointmentService = new AppointmentService ("123456789", date, "Scheduled");
		boolean result = AppointmentService.addAppt("123456789", date, "Scheduled") != null;
		assertTrue(result);
	}

	@Test
	void testDeleteAppt() {
		AppointmentService appointmentService = new AppointmentService ("123456789", date, "Scheduled");
		boolean result = null != AppointmentService.addAppt("123456789", date, "Scheduled");
		Appointment a = appointmentService.deleteAppt("123456789"); assertTrue(a != null);
	}

}
