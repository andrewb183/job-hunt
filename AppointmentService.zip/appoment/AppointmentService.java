package appoment;

import java.util.ArrayList; 
import java.util.Date; 
import java.util.List; 
import java.util.UUID;
public class AppointmentService {
	
	private static final Appointment Object = null;
	final private static List<Appointment> appointmentList = new ArrayList<Appointment>();
	

		/*private String newUniqueId() {
		//return UUID.randomUUID().toString().substring( 0, Math.min(toString().length(), 10));
		}

		//public AppointmentService() {
		//Appointment appt = new Appointment(newUniqueId()); 
		//appointmentList.add(appt);
		}

		//public AppointmentService(Date date) {
		//Appointment appt = new Appointment(newUniqueId(), date); 
		//appointmentList.add(appt);
		}

		//public AppointmentService(Date date, String description) {
		//Appointment appt = new Appointment(newUniqueId(), date, description); appointmentList.add(appt);
		}

		//public AppointmentService(final String id) throws Exception { appointmentList.remove(searchForAppointment(id));
		//Object appt = null;
		 * 
		 */
	
	//}

	public AppointmentService(String string, Date date, String string2) {

	}

	/*protected List<Appointment> getAppointmentList() { 
		//return appointmentList; 
	
	} 
	
	//private Appointment searchForAppointment(String id) throws Exception {
	//int index = 0;
	//while (index < appointmentList.size()) {
	//if (id.equals(appointmentList.get(index).getAppointmentId())) { return appointmentList.get(index);
	}
	//index++;
	 * 
	 */
	//}
	//throw new Exception("The appointment does not exist!");
	//}

	public static Appointment addAppt(String string, Date date, String string2) {
		
		appointmentList.add(new Appointment(string, date, string2));
      	return new Appointment(string, date, string2);
	}

	public Appointment deleteAppt(String string) {
	
		for (Appointment a: appointmentList) {
          if (a.getAppointmentId().equals(string)) {
            appointmentList.remove(a);
          	return a;
        }
	}
		return null; }}
	